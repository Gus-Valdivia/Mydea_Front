let mneg_nav = document.getElementById("btn_neg_nav");
let mneg_nav2 = document.getElementById("btn_neg2_nav");
let mneg_h = document.getElementById("btn_neg_h");
let fbk_h = document.getElementById("btn_fbk_h");
let fbk_nav = document.getElementById("btn_fbk_nav");

mneg_nav.addEventListener("click", ()=>{
    window.location.href = "Mis_Negocios.jsp";
});

mneg_nav2.addEventListener("click", ()=>{
    window.location.href = "Mis_Negocios.jsp";
});

mneg_h.addEventListener("click", ()=>{
    window.location.href = "Mis_Negocios.jsp";
});

fbk_h.addEventListener("click", ()=>{
    window.location.href = "Feedback.jsp";
});

fbk_nav.addEventListener("click", ()=>{
    window.location.href = "Feedback.jsp";
});